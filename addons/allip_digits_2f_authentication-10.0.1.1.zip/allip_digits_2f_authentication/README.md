Please refer to the link below for description & documentation
--------------------------------------------------------------
https://www.odoo.com/apps/modules/10.0/allip_digits_2f_authentication/
